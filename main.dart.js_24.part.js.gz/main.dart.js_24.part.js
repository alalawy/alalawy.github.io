self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var D={
ahG(){return new D.Iy(null)},
Iy:function Iy(d){this.a=d}},A,E,I,F,G,K,C,H,L,B
D=a.updateHolder(c[5],D)
A=c[0]
E=c[21]
I=c[24]
F=c[20]
G=c[25]
K=c[22]
C=c[23]
H=c[2]
L=c[26]
B=c[27]
D.Iy.prototype={
H(d){var x=null,w="Poppins",v=y.e
return A.bv(x,E.jJ(I.aQ,A.a([F.c5("assets/images/Group_132.webp",G.ax,1/0,600),new A.f0(new E.d0(0,0.99),x,x,K.bB(A.a([new A.Z(new C.W(50,0,0,0),F.c5("assets/images/iPhone_14_Pro_(1).webp",G.b3,510,d.X(y.h).f.a.a*0.4),x),new A.Z(new C.W(100,0,0,0),E.fN(A.a([A.as("Kelola Bisnis Anda",x,x,A.ax(x,x,x,x,x,x,x,x,w,x,x,46,x,x,H.y,x,x,!0,x,x,x,x,x,x,x,x),x,x),K.bB(A.a([A.as("Dengan",x,x,A.ax(x,x,x,x,x,x,x,x,w,x,x,46,x,x,H.y,x,x,!0,x,x,x,x,x,x,x,x),x,x),new A.Z(new C.W(10,0,0,0),A.as("Hisabia",x,x,A.ax(x,x,L.a_,x,x,x,x,x,w,x,x,46,x,x,H.y,x,x,!0,x,x,x,x,x,x,x,x),x,x),x)],v),B.J,B.p,B.n),new A.Z(new C.W(0,10,0,0),A.as("Unduh gratis lewat smartphone dan gunakan\naplikasi kasir untuk mengorganisir produk &\nkeuangan Anda.",x,x,A.ax(x,x,new A.x(4285231744),x,x,x,x,x,w,x,x,18,x,x,H.k,x,x,!0,x,x,x,x,x,x,x,x),x,x),x),new A.Z(new C.W(0,20,0,0),K.bB(A.a([F.c5("assets/images/Google_Play_Store_badge_EN.webp",G.aw,45,150),new A.Z(new C.W(15,0,0,0),F.c5("assets/images/Download_on_the_App_Store_Badge.webp",G.aw,45,150),x)],v),B.J,B.p,B.n),x)],v),B.E,B.bh,B.n),x)],v),B.b7,B.p,B.n),x)],v),I.b1),x,x,new E.cC(new A.x(4294638843),x,x,x,x,x,I.R),630,x,x,1/0)}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(D.Iy,A.ag)})()
A.cA(b.typeUniverse,JSON.parse('{"Iy":{"ag":[],"j":[]}}'))
var y={e:A.U("r<j>"),h:A.U("df")}}
$__dart_deferred_initializers__["8YDfF7elZPBvToc0SxIAbBQjbgw="] = $__dart_deferred_initializers__.current
