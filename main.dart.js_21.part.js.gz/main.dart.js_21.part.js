self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var C={q7:function q7(d,e,f,g){var _=this
_.c=d
_.d=e
_.e=f
_.a=g},mn:function mn(d){this.a=d}},D,B,A,J,E
C=a.updateHolder(c[18],C)
D=c[19]
B=c[0]
A=c[2]
J=c[1]
E=c[31]
C.q7.prototype={
H(d){var x,w,v,u,t,s,r,q,p,o,n=null,m=d.X(y.c)
m.toString
x=m.w
w=D.a5z(d).O(d)
m=w.a
v=m==null
if(!v){u=w.b
u=(u==null?n:B.R(u,0,1))!=null&&w.c!=null}else u=!1
if(u)t=w
else{u=w.c
if(u==null)u=24
if(v)m=A.l
v=w.b
v=v==null?n:B.R(v,0,1)
if(v==null)v=B.R(1,0,1)
s=w.d
t=w.nC(m,v,s==null?n:s,u)}r=this.d
if(r==null)r=t.c
m=t.b
q=m==null?n:B.R(m,0,1)
if(q==null)q=1
p=this.e
if(p==null){m=t.a
m.toString
p=m}if(q!==1)p=B.aO(A.d.bb(255*((p.gp(p)>>>24&255)/255*q)),p.gp(p)>>>16&255,p.gp(p)>>>8&255,p.gp(p)&255)
m=B.bz(this.c.a)
o=B.a6v(n,n,A.Eo,n,n,!0,n,B.a3h(n,B.ax(n,n,p,n,n,n,n,n,"MaterialIcons",n,n,r,n,n,n,n,n,!1,n,n,n,n,n,t.d,n,n),m),A.a5,x,n,1,A.bS)
return B.eP(n,new B.pN(!0,D.a39(D.a2m(o,n,n),r,r),n),!1,n,!1,n,n,n,n,n,n,n,n,n,n,n,n,n)}}
C.mn.prototype={
k(d,e){var x
if(e==null)return!1
if(J.O(e)!==B.C(this))return!1
if(e instanceof C.mn)if(e.a===this.a)x=!0
else x=!1
else x=!1
return x},
gq(d){return B.P(this.a,"MaterialIcons",null,!1,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a)},
h(d){return"IconData(U+"+A.c.lO(A.f.iI(this.a,16).toUpperCase(),5,"0")+")"}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(C.q7,B.ag)
x(C.mn,B.z)})()
B.cA(b.typeUniverse,JSON.parse('{"q7":{"ag":[],"j":[]}}'))
var y={c:B.U("dq")};(function constants(){E.jy=new D.tc(0,0,null,null)})()}
$__dart_deferred_initializers__["8YFJ/Oay0QkVroRbLPCzm8pT9rU="] = $__dart_deferred_initializers__.current
