self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var B={
ahI(){return new B.IA(null)},
IA:function IA(d){this.a=d}},A,C,D,E
B=a.updateHolder(c[15],B)
A=c[32]
C=c[0]
D=c[23]
E=c[2]
B.IA.prototype={
H(d){return A.BY}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(B.IA,C.ag)})()
C.cA(b.typeUniverse,JSON.parse('{"IA":{"ag":[],"j":[]}}'));(function constants(){A.xo=new D.W(0,100,0,0)
A.FR=new C.n(!0,null,null,"Poppins",null,null,36,E.y,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
A.HO=new C.tr("Lengkapi Kebutuhan Kasir Anda",null,A.FR,null,null,null,null,null)
A.BY=new C.Z(A.xo,A.HO,null)})()}
$__dart_deferred_initializers__["Jj7LpldVKKyIm4BFkBRqzg3WMAI="] = $__dart_deferred_initializers__.current
