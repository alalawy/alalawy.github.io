self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var A={
ahN(){return new A.IF(null)},
IF:function IF(d){this.a=d}},B,C
A=a.updateHolder(c[11],A)
B=c[0]
C=c[2]
A.IF.prototype={
H(d){var y=null
return B.as("Sesuai Dengan Budget Anda",y,y,B.ax(y,y,y,y,y,y,y,y,"Poppins",y,y,36,y,y,C.y,y,y,!0,y,y,y,y,y,y,y,y),y,y)}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(A.IF,B.ag)})()
B.cA(b.typeUniverse,JSON.parse('{"IF":{"ag":[],"j":[]}}'))}
$__dart_deferred_initializers__["JhMAzYYuOcWzc+ppXtx9XhAfxxg="] = $__dart_deferred_initializers__.current
