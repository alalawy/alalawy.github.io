self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var A={ji:function ji(d,e){this.b=d
this.a=e},
aiv(d){switch(d.a){case 0:return D.bt
case 1:return D.au}},
oX:function oX(d,e){this.a=d
this.b=e},
tN:function tN(d,e){this.a=d
this.b=e},
iO:function iO(){},
Kv:function Kv(){},
a8a(d,e,f){switch(d.a){case 0:switch(e){case C.o:return!0
case C.L:return!1
case null:return null}break
case 1:switch(f){case D.jJ:return!0
case D.IX:return!1
case null:return null}break}},
ye:function ye(d,e){this.a=d
this.b=e},
dH:function dH(d,e,f){var _=this
_.f=_.e=null
_.dD$=d
_.ao$=e
_.a=f},
qE:function qE(d,e){this.a=d
this.b=e},
qD:function qD(d,e){this.a=d
this.b=e},
iS:function iS(d,e){this.a=d
this.b=e},
As:function As(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r){var _=this
_.D=d
_.a1=e
_.aT=f
_.a8=g
_.aw=h
_.aC=i
_.c7=j
_.ct=0
_.cu=k
_.c8=l
_.W_$=m
_.W0$=n
_.d9$=o
_.aZ$=p
_.f4$=q
_.k1=_.id=null
_.k2=!1
_.k4=_.k3=null
_.ok=0
_.d=!1
_.f=_.e=null
_.w=_.r=!1
_.x=null
_.y=!1
_.z=!0
_.Q=null
_.as=!1
_.at=null
_.ax=!1
_.ay=$
_.ch=r
_.CW=!1
_.cx=$
_.cy=!0
_.db=!1
_.dx=null
_.dy=!0
_.fr=null
_.a=0
_.c=_.b=null},
Z_:function Z_(d,e,f){this.a=d
this.b=e
this.c=f},
FK:function FK(){},
FL:function FL(){},
FM:function FM(){},
RB:function RB(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
bB(d,e,f,g){return new A.AO(D.au,f,g,e,null,D.jJ,null,d,null)},
pU:function pU(){},
AO:function AO(d,e,f,g,h,i,j,k,l){var _=this
_.e=d
_.f=e
_.r=f
_.w=g
_.x=h
_.y=i
_.z=j
_.c=k
_.a=l},
a1Q(d,e){var x,w=d.gn(d),v=e.gn(e)
if(w!==v)return!1
if(d===e)return!0
for(w=d.gaU(d),w=w.gP(w);w.t();){x=w.gC(w)
if(!e.Y(0,x)||!J.f(e.j(0,x),d.j(0,x)))return!1}return!0}},J,B,C,D
A=a.updateHolder(c[22],A)
J=c[1]
B=c[0]
C=c[2]
D=c[27]
A.ji.prototype={}
A.oX.prototype={
h(d){return"Axis."+this.b}}
A.tN.prototype={
h(d){return"VerticalDirection."+this.b}}
A.iO.prototype={
j(d,e){return this.b.j(0,e)},
k(d,e){var x=this
if(e==null)return!1
if(x===e)return!0
if(J.O(e)!==B.C(x))return!1
return x.FP(0,e)&&B.u(x).i("iO<iO.T>").b(e)&&A.a1Q(e.b,x.b)},
gq(d){return B.P(B.C(this),this.a,this.b,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a)},
h(d){return"ColorSwatch(primary value: "+this.FQ(0)+")"}}
A.Kv.prototype={}
A.ye.prototype={
h(d){return"FlexFit."+this.b}}
A.dH.prototype={
h(d){return this.mp(0)+"; flex="+B.h(this.e)+"; fit="+B.h(this.f)}}
A.qE.prototype={
h(d){return"MainAxisSize."+this.b}}
A.qD.prototype={
h(d){return"MainAxisAlignment."+this.b}}
A.iS.prototype={
h(d){return"CrossAxisAlignment."+this.b}}
A.As.prototype={
fu(d){if(!(d.e instanceof A.dH))d.e=new A.dH(null,null,C.i)},
dA(d){if(this.D===D.au)return this.BQ(d)
return this.Rj(d)},
mK(d){switch(this.D.a){case 0:return d.b
case 1:return d.a}},
mM(d){switch(this.D.a){case 0:return d.a
case 1:return d.b}},
bW(d){var x
if(this.a8===D.l0)return C.B
x=this.xV(d,B.IQ())
switch(this.D.a){case 0:return d.bl(new B.T(x.a,x.b))
case 1:return d.bl(new B.T(x.b,x.a))}},
xV(a0,a1){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h=this,g=null,f=h.D===D.au?a0.b:a0.d,e=f<1/0,d=h.aZ$
for(x=y.e,w=a0.b,v=a0.d,u=g,t=0,s=0,r=0;d!=null;){q=d.e
q.toString
x.a(q)
p=q.e
if(p==null)p=0
if(p>0){t+=p
u=d}else{if(h.a8===D.l_)switch(h.D.a){case 0:o=B.p4(v,g)
break
case 1:o=B.p4(g,w)
break
default:o=g}else switch(h.D.a){case 0:o=new B.aQ(0,1/0,0,v)
break
case 1:o=new B.aQ(0,w,0,1/0)
break
default:o=g}n=a1.$2(d,o)
r+=h.mM(n)
s=Math.max(s,B.k2(h.mK(n)))}d=q.ao$}m=Math.max(0,(e?f:0)-r)
if(t>0){l=e?m/t:0/0
d=h.aZ$
for(k=0;d!=null;){q=d.e
q.toString
p=x.a(q).e
if(p==null)p=0
if(p>0){if(e)j=d===u?m-k:l*p
else j=1/0
i=B.bb("minChildExtent")
q=d.e
q.toString
q=x.a(q).f
switch((q==null?D.le:q).a){case 0:if(i.b!==i)B.Y(B.P8(i.a))
i.b=j
break
case 1:if(i.b!==i)B.Y(B.P8(i.a))
i.b=0
break}if(h.a8===D.l_)switch(h.D.a){case 0:q=i.b
if(q===i)B.Y(B.fi(i.a))
o=new B.aQ(q,j,v,v)
break
case 1:q=i.b
if(q===i)B.Y(B.fi(i.a))
o=new B.aQ(w,w,q,j)
break
default:o=g}else switch(h.D.a){case 0:q=i.b
if(q===i)B.Y(B.fi(i.a))
o=new B.aQ(q,j,0,v)
break
case 1:q=i.b
if(q===i)B.Y(B.fi(i.a))
o=new B.aQ(0,w,q,j)
break
default:o=g}n=a1.$2(d,o)
r+=h.mM(n)
k+=j
s=Math.max(s,B.k2(h.mK(n)))}q=d.e
q.toString
d=x.a(q).ao$}}return new A.Z_(e&&h.aT===D.n?f:r,s,r)},
bR(){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f=this,e=B.M.prototype.gbf.call(f),d=f.xV(e,B.IR()),a0=d.a,a1=d.b
if(f.a8===D.l0){x=f.aZ$
for(w=y.e,v=0,u=0,t=0;x!=null;){s=f.c7
s.toString
r=x.p6(s,!0)
if(r!=null){v=Math.max(v,r)
u=Math.max(r,u)
t=Math.max(x.k3.b-r,t)
a1=Math.max(u+t,a1)}s=x.e
s.toString
x=w.a(s).ao$}}else v=0
switch(f.D.a){case 0:w=f.k3=e.bl(new B.T(a0,a1))
a0=w.a
a1=w.b
break
case 1:w=f.k3=e.bl(new B.T(a1,a0))
a0=w.b
a1=w.a
break}q=a0-d.c
f.ct=Math.max(0,-q)
p=Math.max(0,q)
o=B.bb("leadingSpace")
n=B.bb("betweenSpace")
w=A.a8a(f.D,f.aw,f.aC)
m=w===!1
switch(f.a1.a){case 0:o.sbA(0)
n.sbA(0)
break
case 1:o.sbA(p)
n.sbA(0)
break
case 2:o.sbA(p/2)
n.sbA(0)
break
case 3:o.sbA(0)
w=f.d9$
n.sbA(w>1?p/(w-1):0)
break
case 4:w=f.d9$
n.sbA(w>0?p/w:0)
o.sbA(n.aa()/2)
break
case 5:w=f.d9$
n.sbA(w>0?p/(w+1):0)
o.sbA(n.aa())
break}l=m?a0-o.aa():o.aa()
x=f.aZ$
for(w=y.e,s=a1/2,k=n.a;x!=null;){j=x.e
j.toString
w.a(j)
i=f.a8
switch(i.a){case 0:case 1:if(A.a8a(A.aiv(f.D),f.aw,f.aC)===(i===D.E))h=0
else{i=x.k3
i.toString
h=a1-f.mK(i)}break
case 2:i=x.k3
i.toString
h=s-f.mK(i)/2
break
case 3:h=0
break
case 4:if(f.D===D.au){i=f.c7
i.toString
r=x.p6(i,!0)
h=r!=null?v-r:0}else h=0
break
default:h=null}if(m){i=x.k3
i.toString
l-=f.mM(i)}switch(f.D.a){case 0:j.a=new B.t(l,h)
break
case 1:j.a=new B.t(h,l)
break}if(m){i=n.b
if(i===n)B.Y(B.fi(k))
l-=i}else{i=x.k3
i.toString
i=f.mM(i)
g=n.b
if(g===n)B.Y(B.fi(k))
l+=i+g}x=j.ao$}},
cv(d,e){return this.tA(d,e)},
al(d,e){var x,w,v,u=this
if(!(u.ct>1e-10)){u.l0(d,e)
return}x=u.k3
if(x.gM(x))return
x=u.c8
w=u.cx
w===$&&B.e()
v=u.k3
x.sb8(0,d.lS(w,e,new B.A(0,0,0+v.a,0+v.b),u.gRk(),u.cu,x.a))},
m(){this.c8.sb8(0,null)
this.j_()},
ia(d){var x
switch(this.cu.a){case 0:return null
case 1:case 2:case 3:if(this.ct>1e-10){x=this.k3
x=new B.A(0,0,0+x.a,0+x.b)}else x=null
return x}},
bw(){var x=this.GZ()
return x}}
A.Z_.prototype={}
A.FK.prototype={
ag(d){var x,w,v
this.eS(d)
x=this.aZ$
for(w=y.e;x!=null;){x.ag(d)
v=x.e
v.toString
x=w.a(v).ao$}},
a7(d){var x,w,v
this.dQ(0)
x=this.aZ$
for(w=y.e;x!=null;){x.a7(0)
v=x.e
v.toString
x=w.a(v).ao$}}}
A.FL.prototype={}
A.FM.prototype={}
A.RB.prototype={
k(d,e){var x=this
if(e==null)return!1
if(x===e)return!0
return e instanceof A.RB&&e.a===x.a&&e.b===x.b&&e.c===x.c&&e.d===x.d},
gq(d){var x=this
return B.P(x.a,x.b,x.c,x.d,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a,C.a)},
h(d){var x=this
return"RelativeRect.fromLTRB("+C.d.I(x.a,1)+", "+C.d.I(x.b,1)+", "+C.d.I(x.c,1)+", "+C.d.I(x.d,1)+")"}}
A.pU.prototype={
gNl(){switch(this.e.a){case 0:return!0
case 1:var x=this.w
return x===D.E||x===D.b7}},
vX(d){var x=this.x
x=this.gNl()?B.e9(d):null
return x},
aq(d){var x=this,w=null,v=new A.As(x.e,x.f,x.r,x.w,x.vX(d),x.y,x.z,C.I,B.aF(),B.bg(4,B.a3f(w,w,w,w,w,C.a5,C.o,w,1,C.bS),!1,y.h),!0,0,w,w,B.aF())
v.av()
v.K(0,w)
return v},
aE(d,e){var x=this,w=x.e
if(e.D!==w){e.D=w
e.a0()}w=x.f
if(e.a1!==w){e.a1=w
e.a0()}w=x.r
if(e.aT!==w){e.aT=w
e.a0()}w=x.w
if(e.a8!==w){e.a8=w
e.a0()}w=x.vX(d)
if(e.aw!=w){e.aw=w
e.a0()}w=x.y
if(e.aC!==w){e.aC=w
e.a0()}if(C.I!==e.cu){e.cu=C.I
e.ac()
e.aP()}}}
A.AO.prototype={}
var z=a.updateTypes([]);(function inheritance(){var x=a.mixinHard,w=a.mixin,v=a.inherit,u=a.inheritMany
v(A.iO,B.x)
v(A.ji,A.iO)
u(B.ht,[A.oX,A.tN,A.ye,A.qE,A.qD,A.iS])
u(B.z,[A.Kv,A.Z_,A.RB])
v(A.dH,B.iR)
v(A.FK,B.F)
v(A.FL,A.FK)
v(A.FM,A.FL)
v(A.As,A.FM)
v(A.pU,B.dN)
v(A.AO,A.pU)
x(A.FK,B.bw)
w(A.FL,B.cT)
w(A.FM,A.Kv)})()
B.cA(b.typeUniverse,JSON.parse('{"ji":{"iO":["q"],"x":[],"iO.T":"q"},"oX":{"G":[]},"tN":{"G":[]},"iO":{"x":[]},"dH":{"dE":[],"f3":["F"],"cF":[]},"ye":{"G":[]},"qE":{"G":[]},"qD":{"G":[]},"iS":{"G":[]},"As":{"cT":["F","dH"],"F":[],"bw":["F","dH"],"M":[],"H":[],"aq":[],"bw.1":"dH","cT.1":"dH"},"pU":{"dN":[],"aE":[],"j":[]},"AO":{"dN":[],"aE":[],"j":[]}}'))
var y={e:B.U("dH"),h:B.U("BJ")};(function constants(){D.au=new A.oX(0,"horizontal")
D.bt=new A.oX(1,"vertical")
D.E=new A.iS(0,"start")
D.b7=new A.iS(1,"end")
D.J=new A.iS(2,"center")
D.l_=new A.iS(3,"stretch")
D.l0=new A.iS(4,"baseline")
D.le=new A.ye(0,"tight")
D.p=new A.qD(0,"start")
D.bh=new A.qD(2,"center")
D.n=new A.qE(1,"max")
D.IX=new A.tN(0,"up")
D.jJ=new A.tN(1,"down")})()}
$__dart_deferred_initializers__["UvZi5z8nCdCWGVUDEJVYQxUKo4g="] = $__dart_deferred_initializers__.current
