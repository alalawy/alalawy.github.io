self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var B={
ahK(){return new B.IC(null)},
IC:function IC(d){this.a=d}},A,D,C
B=a.updateHolder(c[8],B)
A=c[0]
D=c[23]
C=c[2]
B.IC.prototype={
H(d){var y=null
return new A.Z(new D.W(0,10,0,0),A.as("Berbagai macam mesin kasir kami sediakan untuk\nmempermudah transaksi & pembayaran.",y,y,A.ax(y,y,new A.x(4285231744),y,y,y,y,y,"Poppins",y,y,18,y,y,C.k,y,y,!0,y,y,y,y,y,y,y,y),C.dV,y),y)}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(B.IC,A.ag)})()
A.cA(b.typeUniverse,JSON.parse('{"IC":{"ag":[],"j":[]}}'))}
$__dart_deferred_initializers__["/yH2gTM8RtazcQMLWEGREWnDOYw="] = $__dart_deferred_initializers__.current
