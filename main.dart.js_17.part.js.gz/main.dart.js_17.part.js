self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var B={
ahM(){return new B.IE(null)},
IE:function IE(d){this.a=d}},A,D,F,E,G,C
B=a.updateHolder(c[10],B)
A=c[0]
D=c[23]
F=c[22]
E=c[2]
G=c[26]
C=c[27]
B.IE.prototype={
H(d){var x=null
return new A.Z(new D.W(0,100,0,0),F.bB(A.a([A.as("Dapatkan Penawaran",x,x,A.ax(x,x,x,x,x,x,x,x,"Poppins",x,x,36,x,x,E.y,x,x,!0,x,x,x,x,x,x,x,x),x,x),new A.Z(new D.W(10,0,0,0),A.as("Harga",x,x,A.ax(x,x,G.a_,x,x,x,x,x,"Poppins",x,x,36,x,x,E.y,x,x,!0,x,x,x,x,x,x,x,x),x,x),x)],y.a),C.J,C.bh,C.n),x)}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(B.IE,A.ag)})()
A.cA(b.typeUniverse,JSON.parse('{"IE":{"ag":[],"j":[]}}'))
var y={a:A.U("r<j>")}}
$__dart_deferred_initializers__["N0XubMMN6M7sWfM0mSg8QYKCkug="] = $__dart_deferred_initializers__.current
