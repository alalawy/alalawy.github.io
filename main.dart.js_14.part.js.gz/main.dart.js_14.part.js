self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var C={
ahL(){return new C.ID(null)},
ID:function ID(d){this.a=d},
a1i:function a1i(){},
a1j:function a1j(){},
a1k:function a1k(){}},A,E,B,F,L,M,G,H,I,K,N,D,O
C=a.updateHolder(c[9],C)
A=c[0]
E=c[21]
B=c[28]
F=c[17]
L=c[25]
M=c[20]
G=c[24]
H=c[2]
I=c[23]
K=c[19]
N=c[26]
D=c[27]
O=c[22]
C.ID.prototype={
H(d){var x,w,v=null,u="Poppins",t="Beli Perangkat",s=A.bv(v,v,v,v,new E.cC(B.fh,F.x9(L.ax,M.c5("assets/images/Component_1.webp",v,v,v).c),v,v,v,v,G.R),372,v,v,372),r=A.as("Tablet Samsung A7 Lite\n",v,v,A.ax(v,v,v,v,v,v,v,v,u,v,v,26,v,v,v,v,v,!0,v,v,v,v,v,v,v,v),v,v),q=A.ax(v,v,H.h,v,v,v,v,v,u,v,v,v,v,v,H.k,v,v,!0,v,v,v,v,v,v,v,v),p=y.a
q=E.fN(A.a([s,new A.Z(new I.W(0,20,0,0),r,v),new A.Z(new I.W(0,20,0,0),F.y5(new C.a1i(),F.y4(K.fH(8),new E.cn(H.T,1,G.an,G.X),N.a_,60,q,372),t),v)],p),D.E,D.p,D.n)
r=A.bv(v,v,v,v,new E.cC(B.fh,F.x9(L.ax,M.c5("assets/images/Frame_130.webp",v,v,v).c),v,v,v,v,G.R),372,v,v,372)
s=A.as("Tablet iMin D1\n",v,v,A.ax(v,v,v,v,v,v,v,v,u,v,v,26,v,v,v,v,v,!0,v,v,v,v,v,v,v,v),v,v)
x=A.ax(v,v,H.h,v,v,v,v,v,u,v,v,v,v,v,H.k,v,v,!0,v,v,v,v,v,v,v,v)
x=E.fN(A.a([r,new A.Z(new I.W(0,20,0,0),s,v),new A.Z(new I.W(0,20,0,0),F.y5(new C.a1j(),F.y4(K.fH(8),new E.cn(H.T,1,G.an,G.X),N.a_,60,x,372),t),v)],p),D.E,D.p,D.n)
s=A.bv(v,v,v,v,new E.cC(B.fh,F.x9(L.ax,M.c5("assets/images/Frame_131.webp",v,v,v).c),v,v,v,v,G.R),372,v,v,372)
r=A.as("Bluetooth Printer Iware \nC58BT",v,v,A.ax(v,v,v,v,v,v,v,v,u,v,v,26,v,v,v,v,v,!0,v,v,v,v,v,v,v,v),v,v)
w=A.ax(v,v,H.h,v,v,v,v,v,u,v,v,v,v,v,H.k,v,v,!0,v,v,v,v,v,v,v,v)
return new A.Z(new I.W(0,30,0,0),K.a37(O.bB(A.a([new A.Z(new I.W(0,0,20,0),q,v),new A.Z(new I.W(0,0,20,0),x,v),E.fN(A.a([s,new A.Z(new I.W(0,20,0,0),r,v),new A.Z(new I.W(0,20,0,0),F.y5(new C.a1k(),F.y4(K.fH(8),new E.cn(H.T,1,G.an,G.X),N.a_,60,w,372),t),v)],p),D.E,D.p,D.n)],p),D.J,D.p,D.n),D.au),v)}}
var z=a.updateTypes([])
C.a1i.prototype={
$0(){A.fE("Button pressed ...")},
$S:2}
C.a1j.prototype={
$0(){A.fE("Button pressed ...")},
$S:2}
C.a1k.prototype={
$0(){A.fE("Button pressed ...")},
$S:2};(function inheritance(){var x=a.inherit,w=a.inheritMany
x(C.ID,A.ag)
w(A.fL,[C.a1i,C.a1j,C.a1k])})()
A.cA(b.typeUniverse,JSON.parse('{"ID":{"ag":[],"j":[]}}'))
var y={a:A.U("r<j>")};(function constants(){B.wQ=new A.x(4294966759)
B.wP=new A.x(4294965700)
B.wO=new A.x(4294964637)
B.wN=new A.x(4294963574)
B.wM=new A.x(4294962776)
B.wK=new A.x(4294961979)
B.wH=new A.x(4294826037)
B.wG=new A.x(4294688813)
B.wF=new A.x(4294551589)
B.wE=new A.x(4294278935)
B.Be=new A.by([50,B.wQ,100,B.wP,200,B.wO,300,B.wN,400,B.wM,500,B.wK,600,B.wH,700,B.wG,800,B.wF,900,B.wE],A.U("by<q,x>"))
B.fh=new O.ji(B.Be,4294961979)})()}
$__dart_deferred_initializers__["QtTunDrT6OP3KoqDmfwaOjlbd6Q="] = $__dart_deferred_initializers__.current
