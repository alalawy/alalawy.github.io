self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var A={W:function W(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g}},B
A=a.updateHolder(c[23],A)
B=c[0]
A.W.prototype={
gd6(d){return this.a},
gbV(d){return this.b},
gd5(){return this.c},
gc0(d){return this.d},
gcp(d){return 0},
gcq(d){return 0},
E(d,e){if(e instanceof A.W)return this.R(0,e)
return this.wv(0,e)},
U(d,e){var y=this
return new A.W(y.a-e.a,y.b-e.b,y.c-e.c,y.d-e.d)},
R(d,e){var y=this
return new A.W(y.a+e.a,y.b+e.b,y.c+e.c,y.d+e.d)},
S(d,e){var y=this
return new A.W(y.a*e,y.b*e,y.c*e,y.d*e)},
O(d){var y=this
switch(d.a){case 0:return new B.b0(y.c,y.b,y.a,y.d)
case 1:return new B.b0(y.a,y.b,y.c,y.d)}}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(A.W,B.c_)})()
B.cA(b.typeUniverse,JSON.parse('{"W":{"c_":[]}}'))}
$__dart_deferred_initializers__["dy2BaGIufyHSWvLrB44D8psMcnE="] = $__dart_deferred_initializers__.current
