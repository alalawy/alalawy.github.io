self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var B={
ahO(){return new B.IG(null)},
IG:function IG(d){this.a=d}},A,D,C
B=a.updateHolder(c[12],B)
A=c[0]
D=c[23]
C=c[2]
B.IG.prototype={
H(d){var y=null
return new A.Z(new D.W(0,10,0,0),A.as("Kami menawarkan harga aplikasi sesuai dengan\nkebutuhan fitur yang Anda inginkan.",y,y,A.ax(y,y,new A.x(4285231744),y,y,y,y,y,"Poppins",y,y,18,y,y,C.k,y,y,!0,y,y,y,y,y,y,y,y),C.dV,y),y)}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(B.IG,A.ag)})()
A.cA(b.typeUniverse,JSON.parse('{"IG":{"ag":[],"j":[]}}'))}
$__dart_deferred_initializers__["5iaSNNFzBesa33t829DdoR4UkYM="] = $__dart_deferred_initializers__.current
