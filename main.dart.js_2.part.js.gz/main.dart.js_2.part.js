self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var A={
zu(d,e,f){if(e==null)if(d==null)return null
else return d.S(0,1-f)
else if(d==null)return e.S(0,f)
else return new C.t(A.hD(d.a,e.a,f),A.hD(d.b,e.b,f))},
S(d,e,f){var x
if(d!=e)if((d==null?null:isNaN(d))===!0)x=(e==null?null:isNaN(e))===!0
else x=!1
else x=!0
if(x)return d==null?null:d
if(d==null)d=0
if(e==null)e=0
return d*(1-f)+e*f},
hD(d,e,f){return d*(1-f)+e*f},
a0Q(d,e,f){return d*(1-f)+e*f},
a87(d,e){return C.aO(C.oF(B.d.bb((d.gp(d)>>>24&255)*e),0,255),d.gp(d)>>>16&255,d.gp(d)>>>8&255,d.gp(d)&255)},
w(d,e,f){if(e==null)if(d==null)return null
else return A.a87(d,1-f)
else if(d==null)return A.a87(e,f)
else return C.aO(C.oF(B.d.cY(A.a0Q(d.gp(d)>>>24&255,e.gp(e)>>>24&255,f)),0,255),C.oF(B.d.cY(A.a0Q(d.gp(d)>>>16&255,e.gp(e)>>>16&255,f)),0,255),C.oF(B.d.cY(A.a0Q(d.gp(d)>>>8&255,e.gp(e)>>>8&255,f)),0,255),C.oF(B.d.cY(A.a0Q(d.gp(d)&255,e.gp(e)&255,f)),0,255))},
jI:function jI(d,e,f){this.a=d
this.b=e
this.c=f},
d0:function d0(d,e){this.a=d
this.b=e},
kh(d,e,f){var x=d==null
if(x&&e==null)return null
if(x)d=D.av
return d.E(0,(e==null?D.av:e).pw(d).S(0,f))},
oZ:function oZ(){},
cu:function cu(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
uy:function uy(d,e,f,g,h,i,j,k){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j
_.w=k},
f2(d,e){var x=d.c,w=x===D.bu&&d.b===0,v=e.c===D.bu&&e.b===0
if(w&&v)return D.r
if(w)return e
if(v)return d
return new A.cn(d.a,d.b+e.b,x,D.X)},
hI(d,e){var x,w=d.c
if(!(w===D.bu&&d.b===0))x=e.c===D.bu&&e.b===0
else x=!0
if(x)return!0
return w===e.c&&d.a.k(0,e.a)&&d.d===e.d},
ap(d,e,f){var x,w,v,u,t,s,r,q,p
if(f===0)return d
if(f===1)return e
x=d.b
w=e.b
v=A.S(x,w,f)
v.toString
if(v<0)return D.r
u=d.c
t=e.c
if(u===t&&d.d===e.d){x=A.w(d.a,e.a,f)
x.toString
return new A.cn(x,v,u,d.d)}switch(u.a){case 1:s=d.a
break
case 0:u=d.a.a
s=C.aO(0,u>>>16&255,u>>>8&255,u&255)
break
default:s=null}switch(t.a){case 1:r=e.a
break
case 0:u=e.a.a
r=C.aO(0,u>>>16&255,u>>>8&255,u&255)
break
default:r=null}q=d.d
p=e.d
if(q!==p){v=f>0.5
if(v)q=p
u=A.w(s,r,f)
u.toString
t=f*2
if(v){x=A.S(0,w,t-1)
x.toString}else{x=A.S(x,0,t)
x.toString}return new A.cn(u,x,D.an,q)}x=A.w(s,r,f)
x.toString
return new A.cn(x,v,D.an,q)},
a77(d,e,f){var x,w,v,u,t,s,r=d instanceof A.eW?d.a:C.a([d],y.k),q=e instanceof A.eW?e.a:C.a([e],y.k),p=C.a([],y.C),o=Math.max(r.length,q.length)
for(x=1-f,w=0;w<o;++w){v=w<r.length?r[w]:null
u=w<q.length?q[w]:null
t=v!=null
if(t&&u!=null){s=v.bQ(u,f)
if(s==null)s=u.bP(v,f)
if(s!=null){p.push(s)
continue}}if(u!=null)p.push(u.ap(0,f))
if(t)p.push(v.ap(0,x))}return new A.eW(p)},
a8R(d,e,f,g,h,i){var x,w,v,u,t,s=new C.b2(new C.b7())
s.sfA(0)
x=C.dt()
switch(i.c.a){case 1:s.sa4(0,i.a)
x.ef(0)
w=e.a
v=e.b
x.dK(0,w,v)
u=e.c
x.cb(0,u,v)
t=i.b
if(t===0)s.sc_(0,B.D)
else{s.sc_(0,B.aB)
v+=t
x.cb(0,u-h.b,v)
x.cb(0,w+g.b,v)}d.cj(x,s)
break
case 0:break}switch(h.c.a){case 1:s.sa4(0,h.a)
x.ef(0)
w=e.c
v=e.b
x.dK(0,w,v)
u=e.d
x.cb(0,w,u)
t=h.b
if(t===0)s.sc_(0,B.D)
else{s.sc_(0,B.aB)
w-=t
x.cb(0,w,u-f.b)
x.cb(0,w,v+i.b)}d.cj(x,s)
break
case 0:break}switch(f.c.a){case 1:s.sa4(0,f.a)
x.ef(0)
w=e.c
v=e.d
x.dK(0,w,v)
u=e.a
x.cb(0,u,v)
t=f.b
if(t===0)s.sc_(0,B.D)
else{s.sc_(0,B.aB)
v-=t
x.cb(0,u+g.b,v)
x.cb(0,w-h.b,v)}d.cj(x,s)
break
case 0:break}switch(g.c.a){case 1:s.sa4(0,g.a)
x.ef(0)
w=e.a
v=e.d
x.dK(0,w,v)
u=e.b
x.cb(0,w,u)
t=g.b
if(t===0)s.sc_(0,B.D)
else{s.sc_(0,B.aB)
w+=t
x.cb(0,w,u+i.b)
x.cb(0,w,v-f.b)}d.cj(x,s)
break
case 0:break}},
p0:function p0(d,e){this.a=d
this.b=e},
tm:function tm(d,e){this.a=d
this.b=e},
cn:function cn(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
bh:function bh(){},
eW:function eW(d){this.a=d},
XB:function XB(){},
XC:function XC(d){this.a=d},
XD:function XD(){},
a4Z(d,e,f){var x,w,v=y.A
if(v.b(d)&&v.b(e))return A.a2h(d,e,f)
v=y.E
if(v.b(d)&&v.b(e))return A.a2g(d,e,f)
if(e instanceof A.d9&&d instanceof A.dp){f=1-f
x=e
e=d
d=x}if(d instanceof A.d9&&e instanceof A.dp){v=e.b
if(v.k(0,D.r)&&e.c.k(0,D.r))return new A.d9(A.ap(d.a,e.a,f),A.ap(d.b,D.r,f),A.ap(d.c,e.d,f),A.ap(d.d,D.r,f))
w=d.d
if(w.k(0,D.r)&&d.b.k(0,D.r))return new A.dp(A.ap(d.a,e.a,f),A.ap(D.r,v,f),A.ap(D.r,e.c,f),A.ap(d.c,e.d,f))
if(f<0.5){v=f*2
return new A.d9(A.ap(d.a,e.a,f),A.ap(d.b,D.r,v),A.ap(d.c,e.d,f),A.ap(w,D.r,v))}w=(f-0.5)*2
return new A.dp(A.ap(d.a,e.a,f),A.ap(D.r,v,w),A.ap(D.r,e.c,w),A.ap(d.c,e.d,f))}throw C.d(C.a5p(C.a([C.MI("BoxBorder.lerp can only interpolate Border and BorderDirectional classes."),C.be("BoxBorder.lerp() was called with two objects of type "+J.O(d).h(0)+" and "+J.O(e).h(0)+":\n  "+C.h(d)+"\n  "+C.h(e)+"\nHowever, only Border and BorderDirectional classes are supported by this method."),C.MH("For a more general interpolation method, consider using ShapeBorder.lerp instead.")],y.p)))},
a4X(d,e,f,g){var x,w,v,u,t=new C.b2(new C.b7())
t.sa4(0,f.a)
x=f.b
if(x===0){t.sc_(0,B.D)
t.sfA(0)
d.bM(g.bD(e),t)}else{w=f.d
if(w===D.X){v=g.bD(e)
d.fM(v,v.bB(-x),t)}else{if(w===D.jz){w=x/2
u=e.bB(-w)
v=e.bB(w)}else{v=e.bB(x)
u=e}d.fM(g.bD(v),g.bD(u),t)}}},
a4W(d,e,f){var x,w=f.b,v=f.eP()
switch(f.d.a){case 0:x=(e.gcE()-w)/2
break
case 1:x=e.gcE()/2
break
case 2:x=(e.gcE()+w)/2
break
default:x=null}d.eC(e.gaA(),x,v)},
a4Y(d,e,f){var x,w=f.b,v=f.eP()
switch(f.d.a){case 0:x=e.bB(-(w/2))
break
case 1:x=e
break
case 2:x=e.bB(w/2)
break
default:x=null}d.bE(x,v)},
a2h(d,e,f){var x=d==null
if(x&&e==null)return null
if(x)return e.ap(0,f)
if(e==null)return d.ap(0,1-f)
return new A.d9(A.ap(d.a,e.a,f),A.ap(d.b,e.b,f),A.ap(d.c,e.c,f),A.ap(d.d,e.d,f))},
a2g(d,e,f){var x,w,v=d==null
if(v&&e==null)return null
if(v)return e.ap(0,f)
if(e==null)return d.ap(0,1-f)
v=A.ap(d.a,e.a,f)
x=A.ap(d.c,e.c,f)
w=A.ap(d.d,e.d,f)
return new A.dp(v,A.ap(d.b,e.b,f),x,w)},
wC:function wC(d,e){this.a=d
this.b=e},
wA:function wA(){},
d9:function d9(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
dp:function dp(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
a5_(d,e,f){var x,w,v,u,t,s,r
if(f===0)return d
if(f===1)return e
x=A.w(d.a,e.a,f)
w=f<0.5
v=w?d.b:e.b
u=A.a4Z(d.c,e.c,f)
t=A.kh(d.d,e.d,f)
s=A.a50(d.e,e.e,f)
r=A.acP(d.f,e.f,f)
return new A.cC(x,v,u,t,s,r,w?d.w:e.w)},
cC:function cC(d,e,f,g,h,i,j){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.w=j},
X0:function X0(d,e){var _=this
_.b=d
_.e=_.d=_.c=null
_.a=e},
abn(d,e,f){var x,w,v,u,t=A.w(d.a,e.a,f)
t.toString
x=A.zu(d.b,e.b,f)
x.toString
w=A.S(d.c,e.c,f)
w.toString
v=A.S(d.d,e.d,f)
v.toString
u=d.e
return new A.hJ(v,u===B.k7?e.e:u,t,x,w)},
a50(d,e,f){var x,w,v,u,t,s,r,q=d==null
if(q&&e==null)return null
if(q)d=C.a([],y.V)
if(e==null)e=C.a([],y.V)
x=Math.min(d.length,e.length)
q=C.a([],y.V)
for(w=0;w<x;++w){v=A.abn(d[w],e[w],f)
v.toString
q.push(v)}for(v=1-f,w=x;w<d.length;++w){u=d[w]
t=u.a
s=u.b
r=u.c
q.push(new A.hJ(u.d*v,u.e,t,new C.t(s.a*v,s.b*v),r*v))}for(w=x;w<e.length;++w){v=e[w]
u=v.a
t=v.b
s=v.c
q.push(new A.hJ(v.d*f,v.e,u,new C.t(t.a*f,t.b*f),s*f))}return q},
hJ:function hJ(d,e,f,g,h){var _=this
_.d=d
_.e=e
_.a=f
_.b=g
_.c=h},
f6:function f6(){},
p7:function p7(){},
De:function De(){},
a6s(d,e){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j=null,i={}
i.a=e
if(d==null)d=B.eW
x=J.aK(d)
w=x.gn(d)-1
v=C.bg(0,j,!1,y.Z)
u=0<=w
while(!0){if(!!1)break
x.j(d,0)
t=e[0]
t.gdf(t)
break}while(!0){if(!!1)break
x.j(d,w)
s=e[-1]
s.gdf(s)
break}r=C.bb("oldKeyedChildren")
if(u){r.sbA(C.D(y.K,y.O))
for(q=r.a,p=0;p<=w;){o=x.j(d,p)
n=o.d
if(n!=null){m=r.b
if(m===r)C.Y(C.fi(q))
J.k7(m,n,o)}++p}u=!0}else p=0
for(q=r.a,l=0;!1;){t=i.a[l]
if(u){k=t.gdf(t)
n=r.b
if(n===r)C.Y(C.fi(q))
o=J.b8(n,k)
if(o!=null){t.gdf(t)
o=j}}else o=j
v[l]=A.a6r(o,t);++l}x.gn(d)
while(!0){if(!!1)break
v[l]=A.a6r(x.j(d,p),i.a[l]);++l;++p}return new C.bd(v,C.aj(v).i("bd<1,bo>"))},
a6r(d,e){var x,w=d==null?C.Tp(e.gdf(e),null):d,v=e.gDK(),u=C.nj()
v.gFw()
u.id=v.gFw()
u.d=!0
v.gQs(v)
x=v.gQs(v)
u.aY(B.CU,!0)
u.aY(B.D_,x)
v.gF2(v)
u.aY(B.D3,v.gF2(v))
v.gQn(v)
u.aY(B.tz,v.gQn(v))
v.gTG()
u.aY(B.D5,v.gTG())
v.gV7()
u.aY(B.CY,v.gV7())
v.gFt()
u.aY(B.D9,v.gFt())
v.gTy()
u.aY(B.CZ,v.gTy())
v.gUx(v)
u.aY(B.CW,v.gUx(v))
v.gS8()
u.aY(B.tw,v.gS8())
v.gS9(v)
u.aY(B.tx,v.gS9(v))
v.gjv(v)
x=v.gjv(v)
u.aY(B.ty,!0)
u.aY(B.tt,x)
v.gTc()
u.aY(B.D0,v.gTc())
v.glN()
u.aY(B.CV,v.glN())
v.gU_(v)
u.aY(B.D7,v.gU_(v))
v.gT0(v)
u.aY(B.jk,v.gT0(v))
v.gSZ()
u.aY(B.D6,v.gSZ())
v.gEZ()
u.aY(B.tv,v.gEZ())
v.gU0()
u.aY(B.D4,v.gU0())
v.gTI()
u.aY(B.D2,v.gTI())
v.guE()
u.suE(v.guE())
v.gty()
u.sty(v.gty())
v.gVe()
x=v.gVe()
u.aY(B.D8,!0)
u.aY(B.CX,x)
v.gfa(v)
u.aY(B.tu,v.gfa(v))
v.gTz(v)
u.p4=new C.cd(v.gTz(v),B.N)
u.d=!0
v.gp(v)
u.R8=new C.cd(v.gp(v),B.N)
u.d=!0
v.gTd()
u.RG=new C.cd(v.gTd(),B.N)
u.d=!0
v.gRi()
u.rx=new C.cd(v.gRi(),B.N)
u.d=!0
v.gT4(v)
u.ry=new C.cd(v.gT4(v),B.N)
u.d=!0
v.gbv()
u.y1=v.gbv()
u.d=!0
v.ghG()
u.shG(v.ghG())
v.giD()
u.siD(v.giD())
v.got()
u.sot(v.got())
v.gou()
u.sou(v.gou())
v.gov()
u.sov(v.gov())
v.gos()
u.sos(v.gos())
v.guU()
u.suU(v.guU())
v.guP()
u.suP(v.guP())
v.guN(v)
u.suN(0,v.guN(v))
v.guO(v)
u.suO(0,v.guO(v))
v.gv_(v)
u.sv_(0,v.gv_(v))
v.guY()
u.suY(v.guY())
v.guW()
u.suW(v.guW())
v.guZ()
u.suZ(v.guZ())
v.guX()
u.suX(v.guX())
v.gv2()
u.sv2(v.gv2())
v.gv3()
u.sv3(v.gv3())
v.guQ()
u.suQ(v.guQ())
v.guR()
u.suR(v.guR())
v.gor()
u.sor(v.gor())
w.hL(0,B.eW,u)
w.sad(0,e.gad(e))
w.sb6(0,e.gb6(e))
w.dx=e.gWd()
return w},
pp:function pp(){},
Ao:function Ao(d,e,f,g,h,i,j){var _=this
_.A=d
_.Z=e
_.ah=f
_.bq=g
_.dG=h
_.hu=_.ht=_.nX=_.eJ=null
_.B$=i
_.k1=_.id=null
_.k2=!1
_.k4=_.k3=null
_.ok=0
_.d=!1
_.f=_.e=null
_.w=_.r=!1
_.x=null
_.y=!1
_.z=!0
_.Q=null
_.as=!1
_.at=null
_.ax=!1
_.ay=$
_.ch=j
_.CW=!1
_.cx=$
_.cy=!0
_.db=!1
_.dx=null
_.dy=!0
_.fr=null
_.a=0
_.c=_.b=null},
a6t(d,e,f,g){var x,w,v,u,t,s=e.w
if(s!=null&&e.f!=null){x=e.f
x.toString
s.toString
w=D.bW.vw(f.a-x-s)}else{s=e.x
w=s!=null?D.bW.vw(s):D.bW}s=e.e
if(s!=null&&e.r!=null){x=e.r
x.toString
s.toString
w=w.E9(f.b-x-s)}d.dg(w,!0)
v=e.w
if(!(v!=null)){s=e.f
x=d.k3
if(s!=null)v=f.a-s-x.a
else{x.toString
v=g.i1(y.H.a(f.U(0,x))).a}}u=(v<0||v+d.k3.a>f.a)&&!0
t=e.e
if(!(t!=null)){s=e.r
x=d.k3
if(s!=null)t=f.b-s-x.b
else{x.toString
t=g.i1(y.H.a(f.U(0,x))).b}}if(t<0||t+d.k3.b>f.b)u=!0
e.a=new C.t(v,t)
return u},
dj:function dj(d,e,f){var _=this
_.y=_.x=_.w=_.r=_.f=_.e=null
_.dD$=d
_.ao$=e
_.a=f},
ti:function ti(d,e){this.a=d
this.b=e},
rH:function rH(d,e,f,g,h,i,j,k,l){var _=this
_.D=!1
_.a1=null
_.aT=d
_.a8=e
_.aw=f
_.aC=g
_.c7=h
_.d9$=i
_.aZ$=j
_.f4$=k
_.k1=_.id=null
_.k2=!1
_.k4=_.k3=null
_.ok=0
_.d=!1
_.f=_.e=null
_.w=_.r=!1
_.x=null
_.y=!1
_.z=!0
_.Q=null
_.as=!1
_.at=null
_.ax=!1
_.ay=$
_.ch=l
_.CW=!1
_.cx=$
_.cy=!0
_.db=!1
_.dx=null
_.dy=!0
_.fr=null
_.a=0
_.c=_.b=null},
FU:function FU(){},
FV:function FV(){},
Kt(d,e,f,g,h){return new A.po(g,e,h,d,f)},
jJ(d,e,f){return new A.Bv(d,f,e,null)},
fN(d,e,f,g){return new A.wP(F.bt,f,g,e,null,F.jJ,null,d,null)},
po:function po(d,e,f,g,h){var _=this
_.e=d
_.f=e
_.r=f
_.c=g
_.a=h},
Bv:function Bv(d,e,f,g){var _=this
_.e=d
_.r=e
_.c=f
_.a=g},
mX:function mX(d,e,f,g,h,i,j,k){var _=this
_.f=d
_.r=e
_.w=f
_.x=g
_.y=h
_.z=i
_.b=j
_.a=k},
wP:function wP(d,e,f,g,h,i,j,k,l){var _=this
_.e=d
_.f=e
_.r=f
_.w=g
_.x=h
_.y=i
_.z=j
_.c=k
_.a=l},
hr:function hr(){},
dh:function dh(){},
mT:function mT(d,e,f){var _=this
_.d=_.c=_.b=_.a=_.ch=null
_.e=$
_.f=d
_.r=null
_.w=e
_.z=_.y=null
_.Q=!1
_.as=!0
_.ay=_.ax=_.at=!1
_.$ti=f},
QC:function QC(d){this.a=d},
a6S(d){var x=d.X(y.h),w=x==null?null:x.f
return w!==!1},
acP(d,e,f){return null}},C,B,J,D,E,G,F
A=a.updateHolder(c[21],A)
C=c[0]
B=c[2]
J=c[1]
D=c[24]
E=c[23]
G=c[22]
F=c[27]
A.jI.prototype={
ap(d,e){return new A.jI(this.a,this.b.S(0,e),this.c*e)},
k(d,e){var x=this
if(e==null)return!1
if(x===e)return!0
return e instanceof A.jI&&e.a.k(0,x.a)&&e.b.k(0,x.b)&&e.c===x.c},
gq(d){return C.P(this.a,this.b,this.c,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a)},
h(d){return"TextShadow("+this.a.h(0)+", "+this.b.h(0)+", "+C.h(this.c)+")"}}
A.d0.prototype={
geV(){return 0},
geU(d){return this.a},
geW(){return this.b},
U(d,e){return new A.d0(this.a-e.a,this.b-e.b)},
R(d,e){return new A.d0(this.a+e.a,this.b+e.b)},
S(d,e){return new A.d0(this.a*e,this.b*e)},
O(d){var x=this
switch(d.a){case 0:return new C.dD(-x.a,x.b)
case 1:return new C.dD(x.a,x.b)}},
h(d){return C.a2b(this.a,this.b)}}
A.oZ.prototype={
pw(d){var x=this
return new A.uy(x.gcH().U(0,d.gcH()),x.gdW().U(0,d.gdW()),x.gdS().U(0,d.gdS()),x.gen().U(0,d.gen()),x.gcI().U(0,d.gcI()),x.gdV().U(0,d.gdV()),x.geo().U(0,d.geo()),x.gdR().U(0,d.gdR()))},
E(d,e){var x=this
return new A.uy(x.gcH().R(0,e.gcH()),x.gdW().R(0,e.gdW()),x.gdS().R(0,e.gdS()),x.gen().R(0,e.gen()),x.gcI().R(0,e.gcI()),x.gdV().R(0,e.gdV()),x.geo().R(0,e.geo()),x.gdR().R(0,e.gdR()))},
h(d){var x,w,v,u,t=this
if(t.gcH().k(0,t.gdW())&&t.gdW().k(0,t.gdS())&&t.gdS().k(0,t.gen()))if(!t.gcH().k(0,B.K))x=t.gcH().a===t.gcH().b?"BorderRadius.circular("+B.d.I(t.gcH().a,1)+")":"BorderRadius.all("+t.gcH().h(0)+")"
else x=null
else{w=""+"BorderRadius.only("
if(!t.gcH().k(0,B.K)){w+="topLeft: "+t.gcH().h(0)
v=!0}else v=!1
if(!t.gdW().k(0,B.K)){if(v)w+=", "
w+="topRight: "+t.gdW().h(0)
v=!0}if(!t.gdS().k(0,B.K)){if(v)w+=", "
w+="bottomLeft: "+t.gdS().h(0)
v=!0}if(!t.gen().k(0,B.K)){if(v)w+=", "
w+="bottomRight: "+t.gen().h(0)}w+=")"
x=w.charCodeAt(0)==0?w:w}if(t.gcI().k(0,t.gdV())&&t.gdV().k(0,t.gdR())&&t.gdR().k(0,t.geo()))if(!t.gcI().k(0,B.K))u=t.gcI().a===t.gcI().b?"BorderRadiusDirectional.circular("+B.d.I(t.gcI().a,1)+")":"BorderRadiusDirectional.all("+t.gcI().h(0)+")"
else u=null
else{w=""+"BorderRadiusDirectional.only("
if(!t.gcI().k(0,B.K)){w+="topStart: "+t.gcI().h(0)
v=!0}else v=!1
if(!t.gdV().k(0,B.K)){if(v)w+=", "
w+="topEnd: "+t.gdV().h(0)
v=!0}if(!t.geo().k(0,B.K)){if(v)w+=", "
w+="bottomStart: "+t.geo().h(0)
v=!0}if(!t.gdR().k(0,B.K)){if(v)w+=", "
w+="bottomEnd: "+t.gdR().h(0)}w+=")"
u=w.charCodeAt(0)==0?w:w}w=x!=null
if(w&&u!=null)return C.h(x)+" + "+u
if(w)return x
if(u!=null)return u
return"BorderRadius.zero"},
k(d,e){var x=this
if(e==null)return!1
if(x===e)return!0
if(J.O(e)!==C.C(x))return!1
return e instanceof A.oZ&&e.gcH().k(0,x.gcH())&&e.gdW().k(0,x.gdW())&&e.gdS().k(0,x.gdS())&&e.gen().k(0,x.gen())&&e.gcI().k(0,x.gcI())&&e.gdV().k(0,x.gdV())&&e.geo().k(0,x.geo())&&e.gdR().k(0,x.gdR())},
gq(d){var x=this
return C.P(x.gcH(),x.gdW(),x.gdS(),x.gen(),x.gcI(),x.gdV(),x.geo(),x.gdR(),B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a)}}
A.cu.prototype={
gcH(){return this.a},
gdW(){return this.b},
gdS(){return this.c},
gen(){return this.d},
gcI(){return B.K},
gdV(){return B.K},
geo(){return B.K},
gdR(){return B.K},
bD(d){var x=this
return C.Re(d,x.c,x.d,x.a,x.b)},
pw(d){if(d instanceof A.cu)return this.U(0,d)
return this.FM(d)},
E(d,e){if(e instanceof A.cu)return this.R(0,e)
return this.FL(0,e)},
U(d,e){var x=this
return new A.cu(x.a.U(0,e.a),x.b.U(0,e.b),x.c.U(0,e.c),x.d.U(0,e.d))},
R(d,e){var x=this
return new A.cu(x.a.R(0,e.a),x.b.R(0,e.b),x.c.R(0,e.c),x.d.R(0,e.d))},
S(d,e){var x=this
return new A.cu(x.a.S(0,e),x.b.S(0,e),x.c.S(0,e),x.d.S(0,e))},
O(d){return this}}
A.uy.prototype={
S(d,e){var x=this
return new A.uy(x.a.S(0,e),x.b.S(0,e),x.c.S(0,e),x.d.S(0,e),x.e.S(0,e),x.f.S(0,e),x.r.S(0,e),x.w.S(0,e))},
O(d){var x=this
switch(d.a){case 0:return new A.cu(x.a.R(0,x.f),x.b.R(0,x.e),x.c.R(0,x.w),x.d.R(0,x.r))
case 1:return new A.cu(x.a.R(0,x.e),x.b.R(0,x.f),x.c.R(0,x.r),x.d.R(0,x.w))}},
gcH(){return this.a},
gdW(){return this.b},
gdS(){return this.c},
gen(){return this.d},
gcI(){return this.e},
gdV(){return this.f},
geo(){return this.r},
gdR(){return this.w}}
A.p0.prototype={
h(d){return"BorderStyle."+this.b}}
A.tm.prototype={
h(d){return"StrokeAlign."+this.b}}
A.cn.prototype={
ap(d,e){var x=Math.max(0,this.b*e),w=e<=0?D.bu:this.c
return new A.cn(this.a,x,w,D.X)},
eP(){switch(this.c.a){case 1:var x=new C.b2(new C.b7())
x.sa4(0,this.a)
x.sfA(this.b)
x.sc_(0,B.D)
return x
case 0:x=new C.b2(new C.b7())
x.sa4(0,B.T)
x.sfA(0)
x.sc_(0,B.D)
return x}},
k(d,e){var x=this
if(e==null)return!1
if(x===e)return!0
if(J.O(e)!==C.C(x))return!1
return e instanceof A.cn&&e.a.k(0,x.a)&&e.b===x.b&&e.c===x.c&&e.d===x.d},
gq(d){var x=this
return C.P(x.a,x.b,x.c,x.d,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a)},
h(d){var x=this,w=x.d
if(w===D.X)return"BorderSide("+x.a.h(0)+", "+B.d.I(x.b,1)+", "+x.c.h(0)+")"
return"BorderSide("+x.a.h(0)+", "+B.d.I(x.b,1)+", "+x.c.h(0)+", "+w.h(0)+")"}}
A.bh.prototype={
dY(d,e,f){return null},
E(d,e){return this.dY(d,e,!1)},
R(d,e){var x=this.E(0,e)
if(x==null)x=e.dY(0,this,!0)
return x==null?new A.eW(C.a([e,this],y.C)):x},
bP(d,e){if(d==null)return this.ap(0,e)
return null},
bQ(d,e){if(d==null)return this.ap(0,1-e)
return null},
h(d){return"ShapeBorder()"}}
A.eW.prototype={
geB(){return B.b.Sb(this.a,D.az,new A.XB())},
dY(d,e,f){var x,w,v,u=e instanceof A.eW
if(!u){x=this.a
w=f?B.b.gL(x):B.b.gF(x)
v=w.dY(0,e,f)
if(v==null)v=e.dY(0,w,!f)
if(v!=null){u=C.az(x,!0,y.n)
u[f?u.length-1:0]=v
return new A.eW(u)}}x=C.a([],y.C)
if(f)B.b.K(x,this.a)
if(u)B.b.K(x,e.a)
else x.push(e)
if(!f)B.b.K(x,this.a)
return new A.eW(x)},
E(d,e){return this.dY(d,e,!1)},
ap(d,e){var x=this.a,w=C.aj(x).i("aP<1,bh>")
return new A.eW(C.az(new C.aP(x,new A.XC(e),w),!0,w.i("bk.E")))},
bP(d,e){return A.a77(d,this,e)},
bQ(d,e){return A.a77(this,d,e)},
eh(d,e){return B.b.gF(this.a).eh(d,e)},
fi(d,e,f){var x,w,v,u,t
for(x=this.a,w=x.length,v=0;v<x.length;x.length===w||(0,C.N)(x),++v){u=x[v]
u.fi(d,e,f)
t=u.geB().O(f)
e=new C.A(e.a+t.a,e.b+t.b,e.c-t.c,e.d-t.d)}},
k(d,e){if(e==null)return!1
if(this===e)return!0
if(J.O(e)!==C.C(this))return!1
return e instanceof A.eW&&C.d6(e.a,this.a)},
gq(d){return C.e1(this.a)},
h(d){var x=this.a,w=C.aj(x).i("cw<1>")
return new C.aP(new C.cw(x,w),new A.XD(),w.i("aP<bk.E,v>")).b0(0," + ")}}
A.wC.prototype={
h(d){return"BoxShape."+this.b}}
A.wA.prototype={
dY(d,e,f){return null},
E(d,e){return this.dY(d,e,!1)},
eh(d,e){var x=C.dt()
x.t6(d)
return x}}
A.d9.prototype={
geB(){var x,w=this
if(w.gjH()){x=w.a
switch(x.d.a){case 0:x=x.b
return new C.b0(x,x,x,x)
case 1:x=x.b/2
return new C.b0(x,x,x,x)
case 2:return D.az}}return new C.b0(w.d.b,w.a.b,w.b.b,w.c.b)},
gjH(){var x,w,v,u=this,t=u.a,s=t.a,r=u.b
if(r.a.k(0,s)&&u.c.a.k(0,s)&&u.d.a.k(0,s)){x=t.b
if(r.b===x&&u.c.b===x&&u.d.b===x){w=t.c
if(r.c===w&&u.c.c===w&&u.d.c===w){v=t.d
t=r.d===v&&u.c.d===v&&u.d.d===v}else t=!1}else t=!1}else t=!1
return t},
dY(d,e,f){var x=this
if(e instanceof A.d9&&A.hI(x.a,e.a)&&A.hI(x.b,e.b)&&A.hI(x.c,e.c)&&A.hI(x.d,e.d))return new A.d9(A.f2(x.a,e.a),A.f2(x.b,e.b),A.f2(x.c,e.c),A.f2(x.d,e.d))
return null},
E(d,e){return this.dY(d,e,!1)},
ap(d,e){var x=this
return new A.d9(x.a.ap(0,e),x.b.ap(0,e),x.c.ap(0,e),x.d.ap(0,e))},
bP(d,e){if(d instanceof A.d9)return A.a2h(d,this,e)
return this.wT(d,e)},
bQ(d,e){if(d instanceof A.d9)return A.a2h(this,d,e)
return this.wU(d,e)},
oz(d,e,f,g,h){var x,w=this
if(w.gjH()){x=w.a
switch(x.c.a){case 0:return
case 1:switch(g.a){case 1:A.a4W(d,e,x)
break
case 0:if(f!=null){A.a4X(d,e,x,f)
return}A.a4Y(d,e,x)
break}return}}A.a8R(d,e,w.c,w.d,w.b,w.a)},
fi(d,e,f){return this.oz(d,e,null,D.R,f)},
k(d,e){var x=this
if(e==null)return!1
if(x===e)return!0
if(J.O(e)!==C.C(x))return!1
return e instanceof A.d9&&e.a.k(0,x.a)&&e.b.k(0,x.b)&&e.c.k(0,x.c)&&e.d.k(0,x.d)},
gq(d){var x=this
return C.P(x.a,x.b,x.c,x.d,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a)},
h(d){var x,w,v=this
if(v.gjH())return"Border.all("+v.a.h(0)+")"
x=C.a([],y.s)
w=v.a
if(!w.k(0,D.r))x.push("top: "+w.h(0))
w=v.b
if(!w.k(0,D.r))x.push("right: "+w.h(0))
w=v.c
if(!w.k(0,D.r))x.push("bottom: "+w.h(0))
w=v.d
if(!w.k(0,D.r))x.push("left: "+w.h(0))
return"Border("+B.b.b0(x,", ")+")"}}
A.dp.prototype={
geB(){var x,w=this
if(w.gjH()){x=w.a
switch(x.d.a){case 0:x=x.b
return new E.W(x,x,x,x)
case 1:x=x.b/2
return new E.W(x,x,x,x)
case 2:return D.xn}}return new E.W(w.b.b,w.a.b,w.c.b,w.d.b)},
gjH(){var x,w,v,u=this,t=u.a,s=t.a,r=u.b
if(!r.a.k(0,s)||!u.c.a.k(0,s)||!u.d.a.k(0,s))return!1
x=t.b
if(r.b!==x||u.c.b!==x||u.d.b!==x)return!1
w=t.c
if(r.c!==w||u.c.c!==w||u.d.c!==w)return!1
v=t.d
if(!(r.d===v&&u.d.d===v&&u.c.d===v))return!1
return!0},
dY(d,e,f){var x,w,v,u=this,t=null
if(e instanceof A.dp){x=u.a
w=e.a
if(A.hI(x,w)&&A.hI(u.b,e.b)&&A.hI(u.c,e.c)&&A.hI(u.d,e.d))return new A.dp(A.f2(x,w),A.f2(u.b,e.b),A.f2(u.c,e.c),A.f2(u.d,e.d))
return t}if(e instanceof A.d9){x=e.a
w=u.a
if(!A.hI(x,w)||!A.hI(e.c,u.d))return t
v=u.b
if(!v.k(0,D.r)||!u.c.k(0,D.r)){if(!e.d.k(0,D.r)||!e.b.k(0,D.r))return t
return new A.dp(A.f2(x,w),v,u.c,A.f2(e.c,u.d))}return new A.d9(A.f2(x,w),e.b,A.f2(e.c,u.d),e.d)}return t},
E(d,e){return this.dY(d,e,!1)},
ap(d,e){var x=this
return new A.dp(x.a.ap(0,e),x.b.ap(0,e),x.c.ap(0,e),x.d.ap(0,e))},
bP(d,e){if(d instanceof A.dp)return A.a2g(d,this,e)
return this.wT(d,e)},
bQ(d,e){if(d instanceof A.dp)return A.a2g(this,d,e)
return this.wU(d,e)},
oz(d,e,f,g,h){var x,w,v,u=this
if(u.gjH()){x=u.a
switch(x.c.a){case 0:return
case 1:switch(g.a){case 1:A.a4W(d,e,x)
break
case 0:if(f!=null){A.a4X(d,e,x,f)
return}A.a4Y(d,e,x)
break}return}}switch(h.a){case 0:w=u.c
v=u.b
break
case 1:w=u.b
v=u.c
break
default:w=null
v=null}A.a8R(d,e,u.d,w,v,u.a)},
fi(d,e,f){return this.oz(d,e,null,D.R,f)},
k(d,e){var x=this
if(e==null)return!1
if(x===e)return!0
if(J.O(e)!==C.C(x))return!1
return e instanceof A.dp&&e.a.k(0,x.a)&&e.b.k(0,x.b)&&e.c.k(0,x.c)&&e.d.k(0,x.d)},
gq(d){var x=this
return C.P(x.a,x.b,x.c,x.d,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a)},
h(d){var x=this,w=C.a([],y.s),v=x.a
if(!v.k(0,D.r))w.push("top: "+v.h(0))
v=x.b
if(!v.k(0,D.r))w.push("start: "+v.h(0))
v=x.c
if(!v.k(0,D.r))w.push("end: "+v.h(0))
v=x.d
if(!v.k(0,D.r))w.push("bottom: "+v.h(0))
return"BorderDirectional("+B.b.b0(w,", ")+")"}}
A.cC.prototype={
gcl(d){var x=this.c
return x==null?null:x.geB()},
ap(d,e){var x=this,w=null,v=A.w(w,x.a,e),u=A.a4Z(w,x.c,e),t=A.kh(w,x.d,e),s=A.a50(w,x.e,e)
return new A.cC(v,x.b,u,t,s,w,x.w)},
guo(){return this.e!=null},
bP(d,e){if(d==null)return this.ap(0,e)
if(d instanceof A.cC)return A.a5_(d,this,e)
return this.FT(d,e)},
bQ(d,e){if(d==null)return this.ap(0,1-e)
if(d instanceof A.cC)return A.a5_(this,d,e)
return this.FU(d,e)},
k(d,e){var x,w=this
if(e==null)return!1
if(w===e)return!0
if(J.O(e)!==C.C(w))return!1
if(e instanceof A.cC)if(J.f(e.a,w.a))if(J.f(e.b,w.b))if(J.f(e.c,w.c))if(J.f(e.d,w.d))if(C.d6(e.e,w.e))x=e.w===w.w
else x=!1
else x=!1
else x=!1
else x=!1
else x=!1
else x=!1
return x},
gq(d){var x=this,w=x.e
w=w==null?null:C.e1(w)
return C.P(x.a,x.b,x.c,x.d,w,x.f,null,x.w,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a)},
CM(d,e,f){var x
switch(this.w.a){case 0:x=this.d
if(x!=null)return x.O(f).bD(new C.A(0,0,0+d.a,0+d.b)).u(0,e)
return!0
case 1:return e.U(0,d.fH(B.i)).gc3()<=Math.min(d.a,d.b)/2}},
BJ(d){return new A.X0(this,d)}}
A.X0.prototype={
zi(d,e,f,g){var x=this.b
switch(x.w.a){case 1:d.eC(e.gaA(),e.gcE()/2,f)
break
case 0:x=x.d
if(x==null)d.bE(e,f)
else d.bM(x.O(g).bD(e),f)
break}},
NF(d,e,f){var x,w,v,u,t,s,r=this.b.e
if(r==null)return
for(x=r.length,w=0;w<r.length;r.length===x||(0,C.N)(r),++w){v=r[w]
u=new C.b2(new C.b7())
u.sa4(0,v.a)
t=v.e
s=v.c
u.sTR(new C.qG(t,s>0?s*0.57735+0.5:0))
t=e.co(v.b)
s=v.d
this.zi(d,new C.A(t.a-s,t.b-s,t.c+s,t.d+s),u,f)}},
ND(d,e,f){var x,w,v=this,u=v.b,t=u.b
if(t==null)return
if(v.e==null)v.e=t.Ra(v.a)
switch(u.w.a){case 1:x=C.rz(e.gaA(),e.gcE()/2)
w=C.dt()
w.B5(x)
break
case 0:u=u.d
if(u!=null){w=C.dt()
w.eu(u.O(f.d).bD(e))}else w=null
break
default:w=null}v.e.Uc(d,e,w,f)},
m(){var x=this.e
if(x!=null)x.m()
this.FO()},
v9(d,e,f){var x,w,v,u=this,t=f.e,s=e.a,r=e.b,q=new C.A(s,r,s+t.a,r+t.b),p=f.d
u.NF(d,q,p)
t=u.b
s=t.a
r=s==null
if(!r||!1){x=u.c
if(x!=null)w=!1
else w=!0
if(w){v=new C.b2(new C.b7())
if(!r)v.sa4(0,s)
u.c=v
s=v}else s=x
s.toString
u.zi(d,q,s,p)}u.ND(d,q,f)
s=t.c
if(s!=null){r=t.d
r=r==null?null:r.O(p)
s.oz(d,q,r,t.w,p)}},
h(d){return"BoxPainter for "+this.b.h(0)}}
A.hJ.prototype={
ap(d,e){var x=this
return new A.hJ(x.d*e,x.e,x.a,x.b.S(0,e),x.c*e)},
k(d,e){var x=this
if(e==null)return!1
if(x===e)return!0
if(J.O(e)!==C.C(x))return!1
return e instanceof A.hJ&&e.a.k(0,x.a)&&e.b.k(0,x.b)&&e.c===x.c&&e.d===x.d&&e.e===x.e},
gq(d){var x=this
return C.P(x.a,x.b,x.c,x.d,x.e,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a)},
h(d){var x=this
return"BoxShadow("+x.a.h(0)+", "+x.b.h(0)+", "+C.hE(x.c)+", "+C.hE(x.d)+", "+x.e.h(0)+")"}}
A.f6.prototype={
bw(){return"Decoration"},
gcl(d){return D.az},
guo(){return!1},
bP(d,e){return null},
bQ(d,e){return null},
CM(d,e,f){return!0}}
A.p7.prototype={
m(){}}
A.De.prototype={}
A.pp.prototype={
V(d,e){var x=this.a
return x==null?null:x.V(0,e)},
J(d,e){var x=this.a
return x==null?null:x.J(0,e)},
gwc(){return null},
wo(d){return this.k7(d)},
ug(d){return null},
h(d){var x=C.bD(this),w=this.a
w=w==null?null:w.h(0)
if(w==null)w=""
return"<optimized out>#"+x+"("+w+")"}}
A.Ao.prototype={
sDA(d){var x=this.A
if(x==d)return
this.A=d
this.y9(d,x)},
sCr(d){var x=this.Z
if(x==d)return
this.Z=d
this.y9(d,x)},
y9(d,e){var x=this,w=d==null
if(w)x.ac()
else if(e==null||C.C(d)!==C.C(e)||d.k7(e))x.ac()
if(x.b!=null){if(e!=null)e.J(0,x.gfe())
if(!w)d.V(0,x.gfe())}if(w){if(x.b!=null)x.aP()}else if(e==null||C.C(d)!==C.C(e)||d.wo(e))x.aP()},
sUj(d){if(this.ah.k(0,d))return
this.ah=d
this.a0()},
ag(d){var x,w=this
w.mu(d)
x=w.A
if(x!=null)x.V(0,w.gfe())
x=w.Z
if(x!=null)x.V(0,w.gfe())},
a7(d){var x=this,w=x.A
if(w!=null)w.J(0,x.gfe())
w=x.Z
if(w!=null)w.J(0,x.gfe())
x.kg(0)},
cv(d,e){var x=this.Z
if(x!=null){x=x.ug(e)
x=x===!0}else x=!1
if(x)return!0
return this.pJ(d,e)},
hA(d){var x=this.A
if(x!=null){x=x.ug(d)
x=x!==!1}else x=!1
return x},
bR(){this.pK()
this.aP()},
kW(d){return d.bl(this.ah)},
zn(d,e,f){var x
C.bb("debugPreviousCanvasSaveCount")
d.bH(0)
if(!e.k(0,B.i))d.ai(0,e.a,e.b)
x=this.k3
x.toString
f.al(d,x)
d.bG(0)},
al(d,e){var x,w,v=this
if(v.A!=null){x=d.gbc(d)
w=v.A
w.toString
v.zn(x,e,w)
v.A5(d)}v.fD(d,e)
if(v.Z!=null){x=d.gbc(d)
w=v.Z
w.toString
v.zn(x,e,w)
v.A5(d)}},
A5(d){},
eA(d){var x,w=this
w.h6(d)
w.eJ=null
x=w.Z
w.nX=x==null?null:x.gwc()
d.a=!1},
kO(d,e,f){var x,w,v,u,t=this
t.ht=A.a6s(t.ht,D.lA)
t.hu=A.a6s(t.hu,D.lA)
x=t.ht
w=x!=null&&!x.gM(x)
x=t.hu
v=x!=null&&!x.gM(x)
x=C.a([],y.L)
if(w){u=t.ht
u.toString
B.b.K(x,u)}B.b.K(x,f)
if(v){u=t.hu
u.toString
B.b.K(x,u)}t.wR(d,e,x)},
jm(){this.pG()
this.hu=this.ht=null}}
A.dj.prototype={
gur(){var x=this
return x.e!=null||x.f!=null||x.r!=null||x.w!=null||x.x!=null||!1},
h(d){var x=this,w=C.a([],y.s),v=x.e
if(v!=null)w.push("top="+C.hE(v))
v=x.f
if(v!=null)w.push("right="+C.hE(v))
v=x.r
if(v!=null)w.push("bottom="+C.hE(v))
v=x.w
if(v!=null)w.push("left="+C.hE(v))
v=x.x
if(v!=null)w.push("width="+C.hE(v))
if(w.length===0)w.push("not positioned")
w.push(x.mp(0))
return B.b.b0(w,"; ")}}
A.ti.prototype={
h(d){return"StackFit."+this.b}}
A.rH.prototype={
fu(d){if(!(d.e instanceof A.dj))d.e=new A.dj(null,null,B.i)},
P2(){var x=this
if(x.a1!=null)return
x.a1=x.aT.O(x.a8)},
sdZ(d){var x=this
if(x.aT.k(0,d))return
x.aT=d
x.a1=null
x.a0()},
sbv(d){var x=this
if(x.a8==d)return
x.a8=d
x.a1=null
x.a0()},
dA(d){return this.BQ(d)},
bW(d){return this.Af(d,C.IQ())},
Af(d,e){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j=this
j.P2()
if(j.d9$===0){x=d.a
w=d.b
v=C.R(1/0,x,w)
u=d.c
t=d.d
s=C.R(1/0,u,t)
return isFinite(v)&&isFinite(s)?new C.T(C.R(1/0,x,w),C.R(1/0,u,t)):new C.T(C.R(0,x,w),C.R(0,u,t))}r=d.a
q=d.c
switch(j.aw.a){case 0:p=new C.aQ(0,d.b,0,d.d)
break
case 1:p=C.wB(new C.T(C.R(1/0,r,d.b),C.R(1/0,q,d.d)))
break
case 2:p=d
break
default:p=null}o=j.aZ$
for(x=y.B,n=q,m=r,l=!1;o!=null;){w=o.e
w.toString
x.a(w)
if(!w.gur()){k=e.$2(o,p)
m=Math.max(m,k.a)
n=Math.max(n,k.b)
l=!0}o=w.ao$}return l?new C.T(m,n):new C.T(C.R(1/0,r,d.b),C.R(1/0,q,d.d))},
bR(){var x,w,v,u,t,s,r,q=this,p=C.M.prototype.gbf.call(q)
q.D=!1
q.k3=q.Af(p,C.IR())
x=q.aZ$
for(w=y.B,v=y.H;x!=null;){u=x.e
u.toString
w.a(u)
if(!u.gur()){t=q.a1
t.toString
s=q.k3
s.toString
r=x.k3
r.toString
u.a=t.i1(v.a(s.U(0,r)))}else{t=q.k3
t.toString
s=q.a1
s.toString
q.D=A.a6t(x,u,t,s)||q.D}x=u.ao$}},
cv(d,e){return this.tA(d,e)},
oA(d,e){this.l0(d,e)},
al(d,e){var x,w=this,v=w.aC,u=v!==B.I&&w.D,t=w.c7
if(u){u=w.cx
u===$&&C.e()
x=w.k3
t.sb8(0,d.lS(u,e,new C.A(0,0,0+x.a,0+x.b),w.gvb(),v,t.a))}else{t.sb8(0,null)
w.l0(d,e)}},
m(){this.c7.sb8(0,null)
this.j_()},
ia(d){var x
switch(this.aC.a){case 0:return null
case 1:case 2:case 3:if(this.D){x=this.k3
x=new C.A(0,0,0+x.a,0+x.b)}else x=null
return x}}}
A.FU.prototype={
ag(d){var x,w,v
this.eS(d)
x=this.aZ$
for(w=y.B;x!=null;){x.ag(d)
v=x.e
v.toString
x=w.a(v).ao$}},
a7(d){var x,w,v
this.dQ(0)
x=this.aZ$
for(w=y.B;x!=null;){x.a7(0)
v=x.e
v.toString
x=w.a(v).ao$}}}
A.FV.prototype={}
A.po.prototype={
aq(d){var x=new A.Ao(this.e,this.f,this.r,!1,!1,null,C.aF())
x.av()
x.saN(null)
return x},
aE(d,e){e.sDA(this.e)
e.sCr(this.f)
e.sUj(this.r)
e.dG=e.bq=!1},
l9(d){d.sDA(null)
d.sCr(null)}}
A.Bv.prototype={
aq(d){var x=C.e9(d)
x=new A.rH(this.e,x,this.r,B.aU,C.aF(),0,null,null,C.aF())
x.av()
x.K(0,null)
return x},
aE(d,e){var x
e.sdZ(this.e)
x=C.e9(d)
e.sbv(x)
x=this.r
if(e.aw!==x){e.aw=x
e.a0()}if(B.aU!==e.aC){e.aC=B.aU
e.ac()
e.aP()}}}
A.mX.prototype={
nt(d){var x,w,v,u=this,t=d.e
t.toString
y.B.a(t)
x=u.f
if(t.w!=x){t.w=x
w=!0}else w=!1
x=u.r
if(t.e!=x){t.e=x
w=!0}x=u.w
if(t.f!=x){t.f=x
w=!0}x=u.x
if(t.r!=x){t.r=x
w=!0}x=u.y
if(t.x!=x){t.x=x
w=!0}if(w){v=d.c
if(v instanceof C.M)v.a0()}}}
A.wP.prototype={}
A.hr.prototype={
nK(){return C.cP(!1,y.y)},
l8(d){return C.cP(!1,y.y)},
Rt(d){var x=d.a
x.toString
return this.l8(x)},
BV(){},
BX(){},
BW(){},
BU(d){},
Rp(d){}}
A.dh.prototype={
bp(d){return new A.mT(this,B.Q,C.u(this).i("mT<dh.T>"))}}
A.mT.prototype={
J7(d){this.aR(new A.QC(d))},
jN(d){var x=this.f
x.toString
this.J7(this.$ti.i("dh<1>").a(x))}}
var z=a.updateTypes(["c_(c_,bh)","bh(bh)","v(bh)","~(h3,t)","L?(bp?,bp?,L)","x?(x?,x?,L)"])
A.XB.prototype={
$2(d,e){return d.E(0,e.geB())},
$S:z+0}
A.XC.prototype={
$1(d){return d.ap(0,this.a)},
$S:z+1}
A.XD.prototype={
$1(d){return d.h(0)},
$S:z+2}
A.QC.prototype={
$1(d){if(d instanceof C.c9)this.a.nt(d.ga5())
else d.aR(this)},
$S:7};(function aliases(){var x=A.oZ.prototype
x.FM=x.pw
x.FL=x.E
x=A.bh.prototype
x.wT=x.bP
x.wU=x.bQ
x=A.f6.prototype
x.FT=x.bP
x.FU=x.bQ
x=A.p7.prototype
x.FO=x.m})();(function installTearOffs(){var x=a.installStaticTearOff,w=a._instance_2u
x(A,"a97",3,null,["$3"],["S"],4,0)
x(A,"dm",3,null,["$3"],["w"],5,0)
w(A.rH.prototype,"gvb","oA",3)})();(function inheritance(){var x=a.mixin,w=a.mixinHard,v=a.inheritMany,u=a.inherit
v(C.z,[A.jI,A.oZ,A.cn,A.bh,A.De,A.p7,A.hr])
u(A.d0,C.iF)
v(A.oZ,[A.cu,A.uy])
v(C.ht,[A.p0,A.tm,A.wC,A.ti])
v(A.bh,[A.eW,A.wA])
u(A.XB,C.hL)
v(C.bm,[A.XC,A.XD,A.QC])
v(A.wA,[A.d9,A.dp])
u(A.f6,A.De)
u(A.cC,A.f6)
u(A.X0,A.p7)
u(A.hJ,A.jI)
u(A.pp,C.a3)
u(A.Ao,C.kZ)
u(A.dj,C.iR)
u(A.FU,C.F)
u(A.FV,A.FU)
u(A.rH,A.FV)
u(A.po,C.aW)
u(A.Bv,C.dN)
u(A.dh,C.am)
u(A.mX,A.dh)
u(A.wP,G.pU)
u(A.mT,C.kW)
x(A.De,C.a_)
w(A.FU,C.bw)
x(A.FV,C.cT)})()
C.cA(b.typeUniverse,JSON.parse('{"p0":{"G":[]},"tm":{"G":[]},"eW":{"bh":[]},"wC":{"G":[]},"wA":{"bh":[]},"d9":{"bh":[]},"dp":{"bh":[]},"cC":{"f6":[]},"hJ":{"jI":[]},"pp":{"a3":[]},"Ao":{"F":[],"aJ":["F"],"M":[],"H":[],"aq":[]},"dj":{"dE":[],"f3":["F"],"cF":[]},"ti":{"G":[]},"rH":{"cT":["F","dj"],"F":[],"bw":["F","dj"],"M":[],"H":[],"aq":[],"bw.1":"dj","cT.1":"dj"},"mX":{"dh":["dj"],"am":[],"j":[],"dh.T":"dj"},"po":{"aW":[],"aE":[],"j":[]},"Bv":{"dN":[],"aE":[],"j":[]},"wP":{"dN":[],"aE":[],"j":[]},"dh":{"am":[],"j":[]},"mT":{"aR":[],"ac":[]},"bE":{"a3":[]},"io":{"aw":[],"am":[],"j":[]},"jP":{"aw":[],"am":[],"j":[]}}'))
var y=(function rtii(){var x=C.U
return{V:x("r<hJ>"),p:x("r<d1>"),L:x("r<bo>"),C:x("r<bh>"),s:x("r<v>"),k:x("r<bh?>"),K:x("eG"),H:x("t"),O:x("bo"),n:x("bh"),B:x("dj"),h:x("jP"),y:x("B"),A:x("d9?"),E:x("dp?"),Z:x("bo?")}})();(function constants(){var x=a.makeConstList
D.aQ=new A.d0(-1,-1)
D.av=new A.cu(B.K,B.K,B.K,B.K)
D.bu=new A.p0(0,"none")
D.X=new A.tm(0,"inside")
D.r=new A.cn(B.l,0,D.bu,D.X)
D.an=new A.p0(1,"solid")
D.bW=new C.aQ(0,1/0,0,1/0)
D.R=new A.wC(0,"rectangle")
D.xn=new E.W(0,0,0,0)
D.az=new C.b0(0,0,0,0)
D.lA=C.a(x([]),C.U("r<ajK>"))
D.DB=new C.T(1/0,1/0)
D.b1=new A.ti(0,"loose")
D.DI=new A.ti(2,"passthrough")
D.jz=new A.tm(1,"center")})()}
$__dart_deferred_initializers__["Ldb7SPTFw5zACVtDI/yHBIGJ92A="] = $__dart_deferred_initializers__.current
